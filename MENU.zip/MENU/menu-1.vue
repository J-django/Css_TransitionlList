<!--
 * @Author: '15623702696' 2458186212@qq.com
 * @Date: 2022-08-02 16:48:23
 * @LastEditors: '15623702696' 2458186212@qq.com
 * @LastEditTime: 2022-08-02 16:51:19
 * @FilePath: \hebei-demo6-vuec:\Users\jiangkainan\Desktop\menu.vue
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->
<template>
<div
    class="menu-hamburger"
    :class="testHandler ? 'active' : ''"
    @click="testHandler = !testHandler"
>
    <span class="hamburger-1"></span>
    <span class="hamburger-2"></span>
    <span class="hamburger-3"></span>
</div>
</template>

<script>
    
export default {
    name:"",
    data(){
        return {
            testHandler:false
        }
    }
}
</script>

<style lang="scss">
.menu-hamburger {
    position: relative;
    padding: 2px;
    width: 26px;
    height: 26px;
    display: flex;
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: flex-start;
    justify-content: center;
    box-sizing: border-box;
    cursor: pointer;
    user-select: none;
    span.hamburger-1,
    span.hamburger-2,
    span.hamburger-3 {
        flex: 1 1;
        position: relative;
        z-index: 1;
        transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
    }
    span.hamburger-1::after,
    span.hamburger-2::after,
    span.hamburger-3::after {
        content: "";
        position: absolute;
        width: 100%;
        height: 2px;
        top: 50%;
        left: 10%;
        border-radius: 4px;
        border: none;
        transform: translate(-10%, -50%);
        background-color: var(--black);
    }
    span.hamburger-1 {
        width: 50%;
    }
    span.hamburger-2 {
        width: 100%;
    }
    span.hamburger-3 {
        width: 75%;
    }
}

.menu-hamburger.active {
    span.hamburger-1 {
        width: 50%;
        transform-origin: bottom right;
        transform: translate(50%, 200%) rotate(45deg);
    }
    span.hamburger-2 {
        width: 100%;
        transform: translate(0%, 10%) rotate(-45deg);
    }
    span.hamburger-3 {
        width: 50%;
        transform-origin: top left;
        transform: translate(60%, -180%) rotate(45deg);
    }
    span.hamburger-1::after {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
    }
    span.hamburger-3::after {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
    }
}
</style>